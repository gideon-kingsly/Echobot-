let prompt = document.querySelector("#prompt");
let submitbtn = document.querySelector("#submit");
let chatContainer = document.querySelector("#chatContainer");
let uploadImageBtn = document.querySelector("#uploadImage");
let imageinput = document.querySelector("#image-input");
let generateImageBtn = document.querySelector("#generateImage");
let endConversationBtn = document.querySelector("#endConversation");
let showLoginBtn = document.querySelector("#showLogin");
let showSignupBtn = document.querySelector("#showSignup");
let logoutBtn = document.querySelector("#logout");
let loginModal = document.querySelector("#loginModal");
let signupModal = document.querySelector("#signupModal");
let closeLoginBtn = document.querySelector("#closeLogin");
let closeSignupBtn = document.querySelector("#closeSignup");
let loginForm = document.querySelector("#loginForm");
let signupForm = document.querySelector("#signupForm");
let themeToggle = document.querySelector("#themeToggle");
let inputArea = document.querySelector("#inputArea");

// Corrected API URL with proper key placement (replace with your valid API key)
const Api_Url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyC40YQ4pHYM0MPXKE-vxsvi-eJHGgX1TFY";

// Pollinations API for image generation
const Pollinations_Api_Url = "https://image.pollinations.ai/prompt/";

let user = {
    message: null,
    file: { mime_type: null, data: null },
    context: [], // Array to store context (user message + AI response pairs)
    lastGeneratedImage: null // Store the last generated image blob
};

let contextTimeout; // Timer for clearing context after inactivity

window.onload = () => {
    const loggedInUser = localStorage.getItem("loggedInUser");
    const theme = localStorage.getItem("theme") || "dark";
    document.body.classList.toggle("light", theme === "light");
    themeToggle.checked = theme === "light";
    if (loggedInUser) {
        showLoginBtn.style.display = "none";
        showSignupBtn.style.display = "none";
        logoutBtn.style.display = "inline-block";
        chatContainer.style.display = "block";
        inputArea.style.display = "flex";
        loginModal.style.display = "none";
        loadConversation(loggedInUser);
        startContextTimeout();
    } else {
        loginModal.style.display = "flex";
    }
};

// Theme Toggle
themeToggle.addEventListener("change", () => {
    document.body.classList.toggle("light", themeToggle.checked);
    const theme = themeToggle.checked ? "light" : "dark";
    localStorage.setItem("theme", theme);
});

// Authentication
loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("loginUsername").value.toLowerCase();
    const password = document.getElementById("loginPassword").value;
    const users = JSON.parse(localStorage.getItem("users") || "{}");

    if (users[username] && users[username].password === password) {
        localStorage.setItem("loggedInUser", username);
        showLoginBtn.style.display = "none";
        showSignupBtn.style.display = "none";
        logoutBtn.style.display = "inline-block";
        loginModal.style.display = "none";
        chatContainer.style.display = "block";
        inputArea.style.display = "flex";
        loadConversation(username);
        startContextTimeout();
    } else {
        alert("Invalid username or password.");
    }
});

signupForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("signupUsername").value.toLowerCase();
    const password = document.getElementById("signupPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const users = JSON.parse(localStorage.getItem("users") || "{}");

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return;
    }
    if (users[username]) {
        alert("Username already exists.");
        return;
    }

    users[username] = { password };
    localStorage.setItem("users", JSON.stringify(users));
    signupModal.style.display = "none";
    loginModal.style.display = "flex";
    document.getElementById("loginUsername").value = username;
});

showLoginBtn.addEventListener("click", () => {
    loginModal.style.display = "flex";
    signupModal.style.display = "none";
});

showSignupBtn.addEventListener("click", () => {
    signupModal.style.display = "flex";
    loginModal.style.display = "none";
});

closeLoginBtn.addEventListener("click", () => loginModal.style.display = "none");
closeSignupBtn.addEventListener("click", () => signupModal.style.display = "none");

logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("loggedInUser");
    showLoginBtn.style.display = "inline-block";
    showSignupBtn.style.display = "inline-block";
    logoutBtn.style.display = "none";
    chatContainer.style.display = "none";
    inputArea.style.display = "none";
    loginModal.style.display = "flex";
    endConversation();
});

// Chatbot Logic
async function generateResponse(aiMessage) {
    let text = aiMessage.querySelector(".message-content");
    const currentUser = localStorage.getItem("loggedInUser");

    const topicMatch = user.message.match(/what (?:was|is) the (?:above|previous) conversation about (\w+)/i);
    if (topicMatch) {
        const topic = topicMatch[1].toLowerCase();
        const firstMessage = getFirstMessageAboutTopic(currentUser, topic);
        text.innerHTML = firstMessage ? `Your first message about "${topic}" was: "${firstMessage}"` : `I couldn’t find any previous messages about "${topic}".`;
        saveConversation(currentUser);
        return;
    }

    if (/what did I say before|past conversation|what was my last message/i.test(user.message)) {
        const pastMessages = getPastUserMessages(currentUser);
        text.innerHTML = pastMessages.length > 0 ? "Here are your past messages:<br>" + pastMessages.join("<br>") : "I don’t have any past messages from you yet.";
        saveConversation(currentUser);
        return;
    }

    if (/what is my name/i.test(user.message)) {
        const storedName = localStorage.getItem(`${currentUser}_name`) || "I don’t know your name yet. Please tell me!";
        text.innerHTML = `Your name is ${storedName}.`;
        saveConversation(currentUser);
        return;
    }

    const nameMatch = user.message.match(/my name is (\w+)/i);
    if (nameMatch) {
        const name = nameMatch[1];
        localStorage.setItem(`${currentUser}_name`, name);
        text.innerHTML = `Nice to meet you, ${name}! I’ll remember that.`;
        saveConversation(currentUser);
        return;
    }

    // Check for KTM bike context
    const ktmMatch = user.message.match(/ktm (\d{3}\s*(?:duke|rc|adventure|super duke r)|this bike)/i);
    let ktmModel = ktmMatch ? ktmMatch[1].toLowerCase() : null;
    if (ktmMatch && user.context.length > 0) {
        const lastContext = user.context[user.context.length - 1];
        let previousResponse = lastContext.ai;
        let feedback = user.message.toLowerCase();

        if (previousResponse && ktmModel === "this bike") {
            if (previousResponse.includes("390 Duke")) ktmModel = "390 duke";
            else if (previousResponse.includes("200 Duke")) ktmModel = "200 duke";
            else if (previousResponse.includes("250 Adventure")) ktmModel = "250 adventure";
        }

        if (ktmModel) {
            let additionalInfo = "";
            switch (ktmModel) {
                case "390 duke":
                    additionalInfo = "The KTM 390 Duke, a popular naked bike, features a 399cc single-cylinder engine producing around 44 HP and 37 Nm of torque. It’s praised for its agile handling, making it great for city riding, with a mileage of about 25-30 kmpl. Recent 2025 reviews highlight its updated TFT display and improved suspension for better comfort.";
                    if (feedback.includes("city riding")) {
                        additionalInfo += " Its lightweight frame (around 149 kg) and quickshifter+ system make it ideal for urban traffic, with sharp cornering thanks to WP upside-down forks.";
                    } else if (feedback.includes("long rides")) {
                        additionalInfo += " For long rides, the ergonomics might feel aggressive, but the optional touring seat and adjustable levers can enhance comfort.";
                    }
                    break;
                case "200 duke":
                    additionalInfo = "The KTM 200 Duke offers a 199cc engine with about 25 HP and 19.2 Nm of torque. It’s a budget-friendly option with a sporty design, achieving around 30-35 kmpl. The 2025 model includes a refined exhaust and better braking with single-channel ABS.";
                    if (feedback.includes("performance")) {
                        additionalInfo += " Its linear power delivery excels in traffic and twisty roads, with a top speed of around 130 kmph.";
                    }
                    break;
                case "250 adventure":
                    additionalInfo = "The KTM 250 Adventure, built for off-road and touring, has a 248cc engine delivering 30 HP and 24 Nm of torque. It offers a mileage of about 35-40 kmpl and long-travel suspension for rugged terrains.";
                    if (feedback.includes("off-road")) {
                        additionalInfo += " Its ground clearance (200 mm) and knobby tires make it a standout for off-road adventures.";
                    }
                    break;
                default:
                    additionalInfo = "I couldn’t find specific details for that KTM model, but KTM bikes are known for high performance and innovative design. Let me know more about the model for a tailored response!";
            }
            text.innerHTML = `Based on our previous discussion about the ${ktmModel.replace("this bike", "mentioned KTM bike")} and your feedback "${user.message}", here’s more: ${additionalInfo}`;
            saveConversation(currentUser);
            user.context.push({ user: user.message, ai: text.innerHTML });
            if (user.context.length > 5) user.context.shift();
            startContextTimeout();
            return;
        }
    }

    if (/ktm/i.test(user.message)) {
        text.innerHTML = "KTM offers a range of high-performance bikes. Popular models include the 390 Duke (urban sport), 200 Duke (entry-level performance), and 250 Adventure (off-road touring). Specify a model for more details!";
        saveConversation(currentUser);
        user.context.push({ user: user.message, ai: text.innerHTML });
        if (user.context.length > 5) user.context.shift();
        startContextTimeout();
        return;
    }

    // Check for image description request
    if (/describe the above image/i.test(user.message)) {
        try {
            let imageData = null;
            let mimeType = "image/png";

            if (user.file.data) {
                imageData = user.file.data;
                mimeType = user.file.mime_type;
            } else if (user.lastGeneratedImage instanceof Blob) {
                imageData = await new Promise((resolve) => {
                    const reader = new FileReader();
                    reader.onloadend = () => resolve(reader.result.split(',')[1]);
                    reader.readAsDataURL(user.lastGeneratedImage);
                });
            } else {
                throw new Error("No valid image to describe. Please upload or generate an image first.");
            }

            let RequestOption = {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    "contents": [{
                        "parts": [
                            { text: "Describe this image in detail:" },
                            { inline_data: { mime_type: mimeType, data: imageData } }
                        ]
                    }]
                })
            };
            let apiResponse = await fetch(Api_Url, RequestOption);
            if (!apiResponse.ok) throw new Error(`HTTP error! Status: ${apiResponse.status} - ${apiResponse.statusText}`);
            let data = await apiResponse.json();
            let description = data.candidates[0].content.parts[0].text || "I couldn’t analyze the image. Please try again.";
            text.innerHTML = `Description of the above image: ${description}`;
            saveConversation(currentUser);
            user.context.push({ user: user.message, ai: text.innerHTML });
            if (user.context.length > 5) user.context.shift();
            startContextTimeout();
        } catch (error) {
            text.innerHTML = `Error analyzing image: ${error.message}. Ensure your API key supports multimodal input (e.g., gemini-1.5-flash) and an image is available. Regenerate your key at https://aistudio.google.com/ if needed.`;
            console.error("Image Analysis Error:", error);
            saveConversation(currentUser);
        }
        return;
    }

    // General AI response with context
    let contextText = user.context.length > 0 ? `Context: ${user.context.map(c => `${c.user}: ${c.ai}`).join(" | ")}` : "";
    let RequestOption = {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            "contents": [{
                "parts": [{ text: `${contextText}\nUser: ${user.message}` }, ...(user.file.data ? [{ inline_data: user.file }] : [])]
            }]
        })
    };
    try {
        let response = await fetch(Api_Url, RequestOption);
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status} - ${response.statusText}`);
        let data = await response.json();
        let apiResponse = data.candidates[0].content.parts[0].text.replace(/\*\*(.*?)\*\*/g, "$1").trim();
        text.innerHTML = apiResponse;
        saveConversation(currentUser);
        user.context.push({ user: user.message, ai: apiResponse });
        if (user.context.length > 5) user.context.shift();
        startContextTimeout();
    } catch (error) {
        text.innerHTML = `Error: Could not get a response. Please verify your Gemini API key at https://aistudio.google.com/ and ensure it supports gemini-1.5-flash. Current error: ${error.message}.`;
        console.error("API Error:", error);
    } finally {
        chatContainer.scrollTo({ top: chatContainer.scrollHeight, behavior: "smooth" });
        user.file = {};
    }
}

function createChatBox(html, classes) {
    let div = document.createElement("div");
    div.innerHTML = html;
    div.classList.add(classes);
    return div;
}

function handlechatResponse(userMessage) {
    if (!userMessage.trim()) return;
    user.message = userMessage;
    let html = `<img src="user-avatar.png" alt="User" class="avatar">
    <div class="message-content">${user.message}${user.file.data ? `<img src="data:${user.file.mime_type};base64,${user.file.data}" class="chooseimg" />` : ""}</div>`;
    prompt.value = "";
    let userChatBox = createChatBox(html, "user-message");
    chatContainer.appendChild(userChatBox);
    chatContainer.scrollTo({ top: chatContainer.scrollHeight, behavior: "smooth" });
    saveConversation(localStorage.getItem("loggedInUser"));

    setTimeout(() => {
        let html = `<img src="ai-avatar.png" alt="AI" class="avatar">
        <div class="message-content"><img src="loading.webp" alt="Loading" class="load"></div>`;
        let aiChatBox = createChatBox(html, "ai-message");
        chatContainer.appendChild(aiChatBox);
        generateResponse(aiChatBox);
    }, 600);
}

function saveConversation(username) {
    if (!username) return;
    const messages = Array.from(chatContainer.children).map((chatBox, index) => {
        const isUser = chatBox.classList.contains("user-message");
        return {
            type: isUser ? "user" : "ai",
            content: chatBox.querySelector(".message-content").innerHTML,
            hasImage: isUser && chatBox.querySelector(".chooseimg") !== null,
            order: index
        };
    });
    localStorage.setItem(`${username}_chat`, JSON.stringify(messages));
    localStorage.setItem(`${username}_context`, JSON.stringify(user.context));
    if (user.lastGeneratedImage instanceof Blob) {
        const reader = new FileReader();
        reader.onloadend = () => {
            localStorage.setItem(`${username}_lastImage`, reader.result.split(',')[1]);
        };
        reader.readAsDataURL(user.lastGeneratedImage);
    }
}

function loadConversation(username) {
    chatContainer.innerHTML = `<div class="ai-message">
        <img src="ai-avatar.png" alt="AI" class="avatar">
        <div class="message-content">Hello! How can I assist you today?</div>
    </div>`;
    const savedConversation = JSON.parse(localStorage.getItem(`${username}_chat`) || "[]");
    user.context = JSON.parse(localStorage.getItem(`${username}_context`) || "[]");
    const lastImageData = localStorage.getItem(`${username}_lastImage`);
    if (lastImageData) {
        fetch(`data:image/png;base64,${lastImageData}`)
            .then(res => res.blob())
            .then(blob => user.lastGeneratedImage = blob)
            .catch(err => console.error("Failed to load last image:", err));
    }
    savedConversation.forEach(msg => {
        const html = msg.type === "user"
            ? `<img src="user-avatar.png" alt="User" class="avatar"><div class="message-content">${msg.content}</div>`
            : `<img src="ai-avatar.png" alt="AI" class="avatar"><div class="message-content">${msg.content}</div>`;
        const chatBox = createChatBox(html, `${msg.type}-message`);
        chatContainer.appendChild(chatBox);
    });
    chatContainer.scrollTo({ top: chatContainer.scrollHeight, behavior: "smooth" });
    startContextTimeout();
}

function getPastUserMessages(username) {
    const savedConversation = JSON.parse(localStorage.getItem(`${username}_chat`) || "[]");
    return savedConversation
        .filter(msg => msg.type === "user")
        .map(msg => msg.content.replace(/<img[^>]*>/g, "[Image]"));
}

function getFirstMessageAboutTopic(username, topic) {
    const savedConversation = JSON.parse(localStorage.getItem(`${username}_chat`) || "[]");
    console.log('Conversation history for', username, ':', savedConversation);
    const firstUserMessage = savedConversation
        .filter(msg => msg.type === "user" && msg.content.toLowerCase().includes(topic.toLowerCase()))
        .sort((a, b) => a.order - b.order)[0];
    const result = firstUserMessage ? firstUserMessage.content.replace(/<img[^>]*>/g, "[Image]") : null;
    console.log('First message about', topic, ':', result);
    return result;
}

function endConversation() {
    const currentUser = localStorage.getItem("loggedInUser");
    if (currentUser) {
        localStorage.removeItem(`${currentUser}_chat`);
        localStorage.removeItem(`${currentUser}_context`);
        localStorage.removeItem(`${currentUser}_lastImage`);
    }
    chatContainer.innerHTML = `<div class="ai-message">
        <img src="ai-avatar.png" alt="AI" class="avatar">
        <div class="message-content">Hello! How can I assist you today?</div>
    </div>`;
    user.message = null;
    user.file = {};
    user.context = [];
    user.lastGeneratedImage = null;
    prompt.value = "";
    clearContextTimeout();
    chatContainer.scrollTo({ top: chatContainer.scrollHeight, behavior: "smooth" });
}

prompt.addEventListener("keydown", (e) => {
    if (e.key === "Enter") handlechatResponse(prompt.value);
});

submitbtn.addEventListener("click", () => handlechatResponse(prompt.value));

// Image Upload
uploadImageBtn.addEventListener("click", () => imageinput.click());

imageinput.addEventListener("change", () => {
    const file = imageinput.files[0];
    if (!file) return;
    let reader = new FileReader();
    reader.onload = (e) => {
        let base64string = e.target.result.split(",")[1];
        user.file = { mime_type: file.type, data: base64string };
        handlechatResponse(prompt.value || `Uploaded image: ${file.name}`);
    };
    reader.readAsDataURL(file);
    imageinput.value = "";
});

// Image Generation with Retry Logic
generateImageBtn.addEventListener("click", async () => {
    const promptText = prompt.value.trim();
    if (!promptText) {
        alert("Please enter a prompt for image generation!");
        return;
    }

    let html = `<img src="ai-avatar.png" alt="AI" class="avatar"><div class="message-content"><img src="loading.webp" alt="Loading" class="load"></div>`;
    let loadingBox = createChatBox(html, "ai-message");
    chatContainer.appendChild(loadingBox);
    chatContainer.scrollTo({ top: chatContainer.scrollHeight, behavior: "smooth" });

    const maxRetries = 3;
    let retryCount = 0;

    async function attemptImageGeneration() {
        try {
            console.log(`Attempt ${retryCount + 1}: Generating image with prompt:`, promptText);
            const imageUrl = `${Pollinations_Api_Url}${encodeURIComponent(promptText)}?nologo=1&width=1920&height=1920`;
            const response = await fetch(imageUrl);
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status} - ${response.statusText}`);
            }
            const blob = await response.blob();
            console.log('Blob received, type:', blob.type);
            const imageUrlObject = URL.createObjectURL(blob);

            const img = document.createElement('img');
            img.src = imageUrlObject;
            img.className = 'chooseimg';
            let html = `<img src="user-avatar.png" alt="User" class="avatar"><div class="message-content"><img src="${imageUrlObject}" class="chooseimg" /></div>`;
            let userChatBox = createChatBox(html, "user-message");
            chatContainer.removeChild(loadingBox);
            chatContainer.appendChild(userChatBox);
            user.message = `Generated image with prompt: ${promptText}`;
            user.lastGeneratedImage = blob;
            saveConversation(localStorage.getItem("loggedInUser"));

            prompt.value = "";
            startContextTimeout();
        } catch (error) {
            console.error(`Attempt ${retryCount + 1} Failed - Image Generation Error:`, error);
            retryCount++;
            if (retryCount < maxRetries) {
                console.log(`Retrying... (${retryCount}/${maxRetries})`);
                setTimeout(attemptImageGeneration, 2000); // Wait 2 seconds before retrying
            } else {
                chatContainer.removeChild(loadingBox);
                let html = `<img src="ai-avatar.png" alt="AI" class="avatar"><div class="message-content">Error loading image after ${maxRetries} attempts: ${error.message}. Try a more descriptive prompt (e.g., 'A majestic lion in the savannah at sunset') or check your network.</div>`;
                let errorBox = createChatBox(html, "ai-message");
                chatContainer.appendChild(errorBox);
            }
        }
    }

    attemptImageGeneration();
});

endConversationBtn.addEventListener("click", endConversation);

// Context Timeout Management
function startContextTimeout() {
    clearContextTimeout();
    contextTimeout = setTimeout(() => {
        user.context = [];
        console.log('Context cleared due to inactivity');
        localStorage.setItem(`${localStorage.getItem("loggedInUser")}_context`, JSON.stringify(user.context));
    }, 5 * 60 * 1000);
}

function clearContextTimeout() {
    if (contextTimeout) clearTimeout(contextTimeout);
}